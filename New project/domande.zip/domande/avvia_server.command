#!/bin/zsh

cd "$(dirname "$0")" || exit 1

echo "Avvio del server del questionario..."
echo "Pagina domande: http://127.0.0.1:8030/domande.html"
echo "Pagina statistiche: http://127.0.0.1:8030/statistiche.html"
echo ""
echo "Per fermare il server premi Control + C."
echo ""

python3 server.py --host 127.0.0.1 --port 8030

echo ""
echo "Server chiuso."
echo "Premi Invio per terminare."
read
